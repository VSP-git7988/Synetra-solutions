import Link from 'next/link';
import { Linkedin, Mail, MapPin, Phone } from 'lucide-react';
import { Logo, SwooshEdge } from './Brand';
import { services, serviceHref } from '@/data/services';
import { industries, industryHref } from '@/data/industries';
import { site } from '@/data/site';

export default function Footer() {
  const col = 'font-display text-sm font-semibold uppercase tracking-[0.16em] text-synetra-sky';
  const link = 'text-[15px] text-white/75 hover:text-white transition-colors';
  return (
    <footer className="mt-auto">
      <SwooshEdge fill="#042257" />
      <div className="bg-synetra-navy text-white">
        <div className="container-site grid gap-12 pb-14 pt-6 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo variant="white" className="h-12" />
            <p className="mt-6 max-w-sm text-[15px] leading-relaxed text-white/70">
              Synetra is an IT consulting partner that plans, builds and runs technology, and brings in the people to deliver it.
            </p>
            <a href={site.linkedin} aria-label="Synetra on LinkedIn" className="mt-6 inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-white/80 transition hover:border-synetra-sky hover:text-white">
              <Linkedin className="h-5 w-5" />
            </a>
          </div>
          <div>
            <p className={col}>Services</p>
            <ul className="mt-5 space-y-3">
              {services.map((s) => <li key={s.slug}><Link href={serviceHref(s)} className={link}>{s.title}</Link></li>)}
            </ul>
          </div>
          <div>
            <p className={col}>Industries</p>
            <ul className="mt-5 space-y-3">
              {industries.map((i) => <li key={i.slug}><Link href={industryHref(i)} className={link}>{i.title}</Link></li>)}
            </ul>
            <p className={`${col} mt-10`}>Company</p>
            <ul className="mt-5 space-y-3">
              <li><Link href="/about/" className={link}>About Us</Link></li>
              <li><Link href="/contact/" className={link}>Contact Us</Link></li>
            </ul>
          </div>
          <div>
            <p className={col}>Get in touch</p>
            <ul className="mt-5 space-y-4 text-[15px] text-white/75">
              <li className="flex gap-3"><Mail className="mt-0.5 h-5 w-5 shrink-0 text-synetra-sky" /><a href={`mailto:${site.email}`} className="hover:text-white">{site.email}</a></li>
              <li className="flex gap-3"><Phone className="mt-0.5 h-5 w-5 shrink-0 text-synetra-sky" /><a href={`tel:${site.phone.replace(/[^+\d]/g, '')}`} className="hover:text-white">{site.phone}</a></li>
              <li className="flex gap-3"><MapPin className="mt-0.5 h-5 w-5 shrink-0 text-synetra-sky" />{site.address}</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="container-site flex flex-col gap-2 py-6 text-sm text-white/55 sm:flex-row sm:items-center sm:justify-between">
            <p>© {new Date().getFullYear()} Synetra Solutions LLC. All rights reserved.</p>
            <p>IT Consulting · Cloud · AI · Talent</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
