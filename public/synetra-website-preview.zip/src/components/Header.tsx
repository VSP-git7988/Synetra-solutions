'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ArrowRight, ChevronDown, Menu, X } from 'lucide-react';
import { Logo, Icon } from './Brand';
import { services, serviceHref } from '@/data/services';
import { industries, industryHref } from '@/data/industries';

type MenuKey = 'services' | 'industries' | null;

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState<MenuKey>(null);
  const [mobile, setMobile] = useState(false);
  const [acc, setAcc] = useState<MenuKey>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobile ? 'hidden' : '';
  }, [mobile]);

  const close = () => { setOpen(null); setMobile(false); };

  return (
    <header
      className={`sticky top-0 z-50 bg-white/95 backdrop-blur transition-all duration-300 ${scrolled ? 'border-b border-synetra-line shadow-[0_6px_24px_-18px_rgba(4,34,87,.35)]' : 'border-b border-transparent'}`}
      onMouseLeave={() => setOpen(null)}
    >
      <div className={`container-site flex items-center justify-between transition-all duration-300 ${scrolled ? 'h-[72px]' : 'h-[88px]'}`}>
        <Logo className={`transition-all duration-300 ${scrolled ? 'h-9 sm:h-10' : 'h-10 sm:h-[52px]'}`} />

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {(['services', 'industries'] as const).map((k) => (
            <button
              key={k}
              className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-[15px] font-medium transition-colors ${open === k ? 'bg-synetra-mist text-synetra-blue' : 'text-synetra-navy hover:text-synetra-blue'}`}
              aria-expanded={open === k}
              aria-haspopup="true"
              onMouseEnter={() => setOpen(k)}
              onClick={() => setOpen(open === k ? null : k)}
            >
              {k === 'services' ? 'Services' : 'Industries'}
              <ChevronDown className={`h-4 w-4 transition-transform ${open === k ? 'rotate-180' : ''}`} />
            </button>
          ))}
          <Link href="/about/" onMouseEnter={() => setOpen(null)} className="rounded-full px-4 py-2 text-[15px] font-medium text-synetra-navy hover:text-synetra-blue">About</Link>
          <Link href="/contact/" onMouseEnter={() => setOpen(null)} className="rounded-full px-4 py-2 text-[15px] font-medium text-synetra-navy hover:text-synetra-blue">Contact</Link>
        </nav>

        <div className="flex items-center gap-3">
          <Link href="/contact/" className="btn-primary hidden !px-5 !py-3 sm:inline-flex">
            Let&apos;s Talk <ArrowRight className="h-4 w-4" />
          </Link>
          <button className="rounded-full p-2 text-synetra-navy lg:hidden" aria-label="Open menu" onClick={() => setMobile(true)}>
            <Menu className="h-7 w-7" />
          </button>
        </div>
      </div>

      {/* Mega menus */}
      {open && (
        <div className="absolute inset-x-0 top-full hidden lg:block">
          <div className="container-site">
            <div className="mt-2 overflow-hidden rounded-3xl border border-synetra-line bg-white shadow-[0_30px_60px_-30px_rgba(4,34,87,.35)]">
              {open === 'services' ? (
                <div className="grid grid-cols-[1fr_300px]">
                  <div className="grid grid-cols-2 gap-1 p-4">
                    {services.map((s) => (
                      <Link key={s.slug} href={serviceHref(s)} onClick={close} className="group flex gap-4 rounded-2xl p-4 hover:bg-synetra-mist">
                        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-synetra-mist text-synetra-blue group-hover:bg-white">
                          <Icon name={s.icon} className="h-5 w-5" />
                        </span>
                        <span>
                          <span className="block font-display text-[15px] font-semibold text-synetra-navy group-hover:text-synetra-blue">{s.title}</span>
                          <span className="mt-1 block text-[13px] leading-snug text-synetra-slate">{s.summary}</span>
                        </span>
                      </Link>
                    ))}
                  </div>
                  <div className="relative flex flex-col justify-between overflow-hidden bg-brand-gradient p-7 text-white">
                    <div>
                      <p className="font-display text-lg font-semibold leading-snug">Not sure where to start?</p>
                      <p className="mt-2 text-sm text-white/80">Tell us what you&apos;re trying to achieve and a consultant will map out the options.</p>
                    </div>
                    <Link href="/contact/" onClick={close} className="btn-white mt-6 self-start !px-5 !py-2.5 text-sm">
                      Talk to a consultant <ArrowRight className="h-4 w-4" />
                    </Link>
                    <span className="pointer-events-none absolute -right-6 -top-6 grid grid-cols-3 gap-2 opacity-25">
                      {Array.from({ length: 9 }).map((_, i) => <span key={i} className="h-5 w-5 rounded-[4px] bg-white" />)}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-1 p-4">
                  {industries.map((ind) => (
                    <Link key={ind.slug} href={industryHref(ind)} onClick={close} className="group flex gap-4 rounded-2xl p-4 hover:bg-synetra-mist">
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-synetra-mist text-synetra-blue group-hover:bg-white">
                        <Icon name={ind.icon} className="h-5 w-5" />
                      </span>
                      <span>
                        <span className="block font-display text-[15px] font-semibold text-synetra-navy group-hover:text-synetra-blue">{ind.title}</span>
                        <span className="mt-1 block text-[13px] leading-snug text-synetra-slate">{ind.summary}</span>
                      </span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mobile overlay */}
      {mobile && (
        <div className="fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-synetra-navy text-white lg:hidden">
          <div className="container-site flex h-[80px] items-center justify-between">
            <Logo variant="white" className="h-9" />
            <button aria-label="Close menu" onClick={() => setMobile(false)} className="rounded-full p-2"><X className="h-7 w-7" /></button>
          </div>
          <nav className="container-site flex flex-1 flex-col gap-2 py-6" aria-label="Mobile">
            {(['services', 'industries'] as const).map((k) => (
              <div key={k} className="border-b border-white/10 py-3">
                <button className="flex w-full items-center justify-between font-display text-2xl font-semibold" onClick={() => setAcc(acc === k ? null : k)} aria-expanded={acc === k}>
                  {k === 'services' ? 'Services' : 'Industries'}
                  <ChevronDown className={`h-6 w-6 transition-transform ${acc === k ? 'rotate-180' : ''}`} />
                </button>
                {acc === k && (
                  <div className="mt-3 flex flex-col gap-1">
                    {(k === 'services' ? services.map((s) => ({ t: s.title, h: serviceHref(s) })) : industries.map((i) => ({ t: i.title, h: industryHref(i) }))).map((l) => (
                      <Link key={l.t} href={l.h} onClick={close} className="rounded-xl px-2 py-2 text-white/80 hover:text-white">{l.t}</Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <Link href="/about/" onClick={close} className="border-b border-white/10 py-3 font-display text-2xl font-semibold">About</Link>
            <Link href="/contact/" onClick={close} className="border-b border-white/10 py-3 font-display text-2xl font-semibold">Contact</Link>
            <Link href="/contact/" onClick={close} className="btn-white mt-8 self-start">Let&apos;s Talk <ArrowRight className="h-4 w-4" /></Link>
          </nav>
        </div>
      )}
    </header>
  );
}
