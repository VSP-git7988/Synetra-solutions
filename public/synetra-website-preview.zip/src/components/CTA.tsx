import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { SwooshLine } from './Brand';
import Reveal from './Reveal';

export default function CTA({
  title = "Let's build what's next, together.",
  text = 'Tell us where you want to go. We will bring the plan, the technology and the people to get you there.',
}: { title?: string; text?: string }) {
  return (
    <section className="py-20 sm:py-24">
      <div className="container-site">
        <Reveal className="relative overflow-hidden rounded-[2rem] bg-brand-gradient px-8 py-14 sm:px-14 sm:py-20">
          <SwooshLine className="pointer-events-none absolute inset-0 h-full w-full opacity-60" color="rgba(255,255,255,.35)" />
          <div className="relative grid items-end gap-10 lg:grid-cols-[1.4fr_1fr]">
            <div>
              <h2 className="max-w-2xl text-3xl font-semibold leading-tight !text-white sm:text-5xl">{title}</h2>
              <p className="mt-5 max-w-xl text-lg text-white/80">{text}</p>
            </div>
            <div className="flex flex-wrap gap-3 lg:justify-end">
              <Link href="/contact/" className="btn-white">Talk to a consultant <ArrowRight className="h-4 w-4" /></Link>
              <Link href="/services/" className="btn-ghost-light">Explore services</Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
