import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { SwooshEdge, SwooshLine } from './Brand';

export default function PageHero({
  eyebrow, title, text, crumbs, children,
}: { eyebrow: string; title: React.ReactNode; text?: string; crumbs: { label: string; href?: string }[]; children?: React.ReactNode }) {
  return (
    <section className="relative">
      <div className="relative overflow-hidden bg-brand-gradient pb-28 pt-14 text-white sm:pb-36 sm:pt-16">
        <SwooshLine className="pointer-events-none absolute inset-0 h-full w-full opacity-70" color="rgba(255,255,255,.28)" />
        <span aria-hidden className="pointer-events-none absolute right-[6%] top-10 hidden grid-cols-3 gap-2.5 opacity-30 md:grid">
          {[1, 1, 0, 1, 1, 1, 0, 1, 1].map((v, i) => <span key={i} className={`h-6 w-6 rounded-[5px] ${v ? 'bg-white' : ''}`} />)}
        </span>
        <div className="container-site relative">
          <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1.5 text-sm text-white/70">
            <Link href="/" className="hover:text-white">Home</Link>
            {crumbs.map((c) => (
              <span key={c.label} className="flex items-center gap-1.5">
                <ChevronRight className="h-3.5 w-3.5" />
                {c.href ? <Link href={c.href} className="hover:text-white">{c.label}</Link> : <span className="text-white" aria-current="page">{c.label}</span>}
              </span>
            ))}
          </nav>
          <div className="mt-8"><span className="eyebrow !text-white/90"><span aria-hidden className="inline-grid grid-cols-2 gap-[3px]"><span className="h-[6px] w-[6px] rounded-[1.5px] bg-white" /><span className="h-[6px] w-[6px] rounded-[1.5px] bg-synetra-sky" /><span className="h-[6px] w-[6px] rounded-[1.5px] bg-white/60" /></span>{eyebrow}</span></div>
          <h1 className="mt-5 max-w-3xl text-4xl font-bold leading-[1.08] !text-white sm:text-6xl">{title}</h1>
          {text && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80 sm:text-xl">{text}</p>}
          {children && <div className="mt-9 flex flex-wrap gap-3">{children}</div>}
        </div>
        <div className="absolute inset-x-0 -bottom-px"><SwooshEdge fill="#ffffff" /></div>
      </div>
    </section>
  );
}
