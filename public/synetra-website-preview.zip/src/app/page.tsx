import Link from 'next/link';
import { ArrowRight, ArrowUpRight, Check } from 'lucide-react';
import { CircuitLines, Eyebrow, Icon, PixelMosaic, SwooshEdge, SwooshLine } from '@/components/Brand';
import Reveal from '@/components/Reveal';
import IndustryTabs from '@/components/IndustryTabs';
import CTA from '@/components/CTA';
import { services, serviceHref } from '@/data/services';
import { capabilities, clients, stats, steps } from '@/data/site';

// Up-right arrow made of logo pixels: "moving your business forward"
const HERO: (0 | 1 | 2 | 3)[][] = [
  [0, 0, 0, 3, 3, 3, 3],
  [0, 0, 0, 0, 2, 3, 3],
  [0, 0, 0, 2, 2, 2, 3],
  [0, 0, 2, 2, 1, 0, 3],
  [0, 1, 2, 1, 0, 0, 0],
  [1, 1, 1, 0, 0, 0, 0],
  [1, 1, 0, 0, 0, 0, 0],
];

export default function Home() {
  const [featured, ...rest] = services;
  return (
    <>
      {/* ---------------- HERO ---------------- */}
      <section className="relative overflow-hidden">
        <SwooshLine animate className="pointer-events-none absolute inset-x-0 -bottom-10 h-[42%] w-full opacity-70" />
        <div className="container-site relative grid items-center gap-14 pb-20 pt-14 lg:grid-cols-[7fr_5fr] lg:pb-28 lg:pt-20">
          <div>
            <Reveal><Eyebrow>IT Consulting · Cloud · AI · Talent</Eyebrow></Reveal>
            <Reveal delay={80}>
              <h1 className="mt-6 text-[2.6rem] font-bold leading-[1.06] sm:text-6xl lg:text-[4.1rem]">
                Technology that <span className="text-gradient">moves</span> your business forward.
              </h1>
            </Reveal>
            <Reveal delay={160}>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-synetra-slate sm:text-xl">
                Synetra plans, builds and runs the AI, cloud and data systems your business depends on, and brings in the IT talent to deliver them.
              </p>
            </Reveal>
            <Reveal delay={240} className="mt-9 flex flex-wrap gap-3">
              <Link href="/services/" className="btn-primary">Explore services <ArrowRight className="h-4 w-4" /></Link>
              <Link href="/contact/" className="btn-outline">Talk to a consultant</Link>
            </Reveal>
            <Reveal delay={320}>
              <ul className="mt-10 flex flex-wrap gap-x-7 gap-y-3 text-[15px] font-medium text-synetra-navy">
                {['Strategy to delivery', 'Certified cloud expertise', 'Vetted IT talent'].map((t) => (
                  <li key={t} className="flex items-center gap-2">
                    <span className="flex h-5 w-5 items-center justify-center rounded-[5px] bg-synetra-mist text-synetra-blue"><Check className="h-3.5 w-3.5" strokeWidth={3} /></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* Visual */}
          <Reveal delay={200} className="relative mx-auto w-full max-w-[460px]">
            <div className="relative rounded-[2.25rem] border border-synetra-line bg-white/80 p-8 shadow-[0_40px_80px_-40px_rgba(4,34,87,.35)] backdrop-blur sm:p-10">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-[0.18em] text-synetra-slate">Synetra · Delivery</span>
                <span className="flex items-center gap-1.5 text-xs font-semibold text-synetra-blue"><span className="h-2 w-2 rounded-full bg-synetra-sky pixel-shimmer" /> Live</span>
              </div>
              <div className="mt-8 flex justify-center">
                <PixelMosaic pattern={HERO} />
              </div>
            </div>
            <div className="floaty absolute -left-4 top-[22%] rounded-2xl border border-synetra-line bg-white px-4 py-3 shadow-[0_18px_40px_-20px_rgba(4,34,87,.4)] sm:-left-12">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-synetra-slate">Cloud migration</p>
              <p className="mt-0.5 flex items-center gap-1.5 font-display text-sm font-semibold text-synetra-navy"><Check className="h-4 w-4 text-synetra-sky" strokeWidth={3} /> Completed</p>
            </div>
            <div className="floaty absolute -right-3 top-[52%] rounded-2xl bg-synetra-navy px-4 py-3 text-white shadow-[0_18px_40px_-20px_rgba(4,34,87,.6)] sm:-right-10" style={{ animationDelay: '1.5s' }}>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-synetra-sky">AI agent</p>
              <p className="mt-0.5 font-display text-sm font-semibold">Deployed to production</p>
            </div>
            <div className="floaty absolute -bottom-5 left-[18%] rounded-2xl border border-synetra-line bg-white px-4 py-3 shadow-[0_18px_40px_-20px_rgba(4,34,87,.4)]" style={{ animationDelay: '3s' }}>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-synetra-slate">Talent</p>
              <p className="mt-0.5 font-display text-sm font-semibold text-synetra-navy">12 engineers onboarded</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------- MARQUEE ---------------- */}
      <section aria-label="Capabilities" className="marquee overflow-hidden border-y border-synetra-line bg-synetra-mist py-5">
        <div className="marquee-track flex w-max gap-10 whitespace-nowrap">
          {[...capabilities, ...capabilities].map((c, i) => (
            <span key={i} className="flex items-center gap-10 font-display text-lg font-medium text-synetra-navy/80">
              {c}<span aria-hidden className="h-2 w-2 rounded-[2px] bg-synetra-sky" />
            </span>
          ))}
        </div>
      </section>

      {/* ---------------- SERVICES BENTO ---------------- */}
      <section className="py-24 sm:py-28">
        <div className="container-site">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <Reveal className="max-w-2xl">
              <Eyebrow>What we do</Eyebrow>
              <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">Six ways we help you build, run and <span className="text-gradient">scale</span>.</h2>
            </Reveal>
            <Reveal delay={100}><Link href="/services/" className="btn-outline">All services <ArrowRight className="h-4 w-4" /></Link></Reveal>
          </div>

          <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            <Reveal as="div" className="md:col-span-2 lg:row-span-2">
              <Link href={serviceHref(featured)} className="group relative flex h-full min-h-[380px] flex-col justify-between overflow-hidden rounded-3xl bg-brand-gradient p-9 text-white">
                <CircuitLines className="pointer-events-none absolute -right-10 -top-6 w-[420px] text-white/15" />
                <span className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15"><Icon name={featured.icon} className="h-7 w-7" /></span>
                <div className="relative">
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-white/70">Featured</p>
                  <h3 className="mt-3 text-3xl font-semibold !text-white sm:text-4xl">{featured.title}</h3>
                  <p className="mt-3 max-w-md text-[17px] text-white/80">{featured.summary}</p>
                  <ul className="mt-6 grid gap-2 text-[15px] text-white/90 sm:grid-cols-2">
                    {featured.offerings.map((o) => <li key={o} className="flex gap-2"><span className="mt-[7px] h-2 w-2 shrink-0 rounded-[2px] bg-synetra-sky" />{o}</li>)}
                  </ul>
                  <span className="mt-8 inline-flex items-center gap-2 font-semibold">Explore AI Solutions <ArrowUpRight className="h-5 w-5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></span>
                </div>
              </Link>
            </Reveal>
            {rest.map((s, i) => (
              <Reveal key={s.slug} delay={i * 70} className={i === 0 || i >= 3 ? 'md:col-span-2 lg:col-span-2' : ''}>
                <Link href={serviceHref(s)} className="card group flex h-full min-h-[200px] flex-col justify-between p-7">
                  <div className="flex items-start justify-between">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-synetra-mist text-synetra-blue transition-colors group-hover:bg-synetra-blue group-hover:text-white"><Icon name={s.icon} /></span>
                    <ArrowUpRight className="h-5 w-5 text-synetra-slate transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-synetra-blue" />
                  </div>
                  <div className="mt-6">
                    <h3 className="text-lg font-semibold leading-snug">{s.title}</h3>
                    <p className="mt-2 text-[15px] leading-relaxed text-synetra-slate">{s.summary}</p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- WHY SYNETRA ---------------- */}
      <section className="relative">
        <SwooshEdge fill="#042257" />
        <div className="relative overflow-hidden bg-synetra-navy pb-16 pt-10 text-white sm:pb-20">
          <CircuitLines className="pointer-events-none absolute -left-20 bottom-0 w-[620px] text-white/[0.06]" />
          <div className="container-site relative grid gap-14 lg:grid-cols-2 lg:items-center">
            <Reveal>
              <Eyebrow light>Why Synetra</Eyebrow>
              <h2 className="mt-5 text-4xl font-semibold leading-tight !text-white sm:text-5xl">One partner for the technology <span className="text-synetra-sky">and</span> the team.</h2>
              <p className="mt-6 max-w-lg text-lg leading-relaxed text-white/75">
                Most firms either advise, build or staff. We do all three, so the strategy, the delivery and the people stay connected from the first workshop to long after go-live.
              </p>
              <ul className="mt-8 space-y-3 text-[16px] text-white/85">
                {['Consultants who have built and run real systems', 'Flexible engagement: project, team or individual experts', 'Clear ownership, reporting and measurable results'].map((t) => (
                  <li key={t} className="flex gap-3"><span className="mt-[7px] h-2 w-2 shrink-0 rounded-[2px] bg-synetra-sky" />{t}</li>
                ))}
              </ul>
            </Reveal>
            <div className="grid grid-cols-2 gap-4 sm:gap-5">
              {stats.map((s, i) => (
                <Reveal key={s.label} delay={i * 90} className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 sm:p-8">
                  <p className="font-display text-4xl font-bold sm:text-5xl">{s.value}</p>
                  <p className="mt-3 text-[14px] leading-snug text-synetra-sky sm:text-[15px]">{s.label}</p>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
        <SwooshEdge fill="#042257" flip />
      </section>

      {/* ---------------- INDUSTRIES ---------------- */}
      <section className="py-24 sm:py-28">
        <div className="container-site">
          <Reveal className="max-w-2xl">
            <Eyebrow>Industries</Eyebrow>
            <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">Deep experience where the stakes are <span className="text-gradient">highest</span>.</h2>
          </Reveal>
          <Reveal delay={100} className="mt-10"><IndustryTabs /></Reveal>
        </div>
      </section>

      {/* ---------------- HOW WE ENGAGE ---------------- */}
      <section className="bg-synetra-mist py-24 sm:py-28">
        <div className="container-site grid gap-14 lg:grid-cols-[1fr_1.4fr]">
          <Reveal className="lg:sticky lg:top-32 lg:self-start">
            <Eyebrow>How we engage</Eyebrow>
            <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">A clear path from first call to lasting results.</h2>
            <p className="mt-6 max-w-md text-lg text-synetra-slate">Every engagement follows the same disciplined rhythm, whether you need a single expert or a full delivery team.</p>
          </Reveal>
          <ol className="relative">
            <span aria-hidden className="absolute bottom-6 left-[19px] top-6 w-px bg-gradient-to-b from-synetra-sky via-synetra-blue to-synetra-navy" />
            {steps.map((s, i) => (
              <Reveal as="li" key={s.title} delay={i * 90} className="relative flex gap-7 pb-10 last:pb-0">
                <span className="relative z-10 grid h-10 w-10 shrink-0 grid-cols-2 gap-[3px] rounded-xl bg-white p-[9px] shadow-[0_8px_20px_-10px_rgba(4,34,87,.4)]">
                  {[0, 1, 2, 3].map((k) => (
                    <span key={k} className={`rounded-[2px] ${k <= i ? (k % 2 ? 'bg-synetra-sky' : 'bg-synetra-blue') : 'bg-synetra-line'}`} />
                  ))}
                </span>
                <div className="card flex-1 p-7">
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-synetra-blue">Step {String(i + 1).padStart(2, '0')}</p>
                  <h3 className="mt-2 text-2xl font-semibold">{s.title}</h3>
                  <p className="mt-2 text-[16px] leading-relaxed text-synetra-slate">{s.text}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* ---------------- CLIENTS ---------------- */}
      <section className="pt-24">
        <div className="container-site">
          <Reveal className="text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-synetra-slate">Trusted by teams across industries</p>
          </Reveal>
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {clients.map((c, i) => (
              <Reveal key={c} delay={i * 40} className="flex h-20 items-center justify-center rounded-2xl border border-dashed border-synetra-line font-display text-lg font-semibold text-synetra-slate/60">
                {c}
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
